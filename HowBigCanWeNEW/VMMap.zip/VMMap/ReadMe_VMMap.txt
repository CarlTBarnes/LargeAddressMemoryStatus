VMMap source from Jeffrey Richter's book Programming Appilcations for Microsoft Windows 4th Edition.

There is a 5th Edition with a different title, like Windows C/C++ Programming. It covers Vista.



