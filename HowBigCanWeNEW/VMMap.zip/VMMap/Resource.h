//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by VMMap.rc
//
#define IDD_VMMAP                       1
#define IDC_LISTBOX                     100
#define IDI_VMMAP                       101
#define IDR_VMMAP                       102
#define ID_REFRESH                      40001
#define ID_EXPANDREGIONS                40002
#define ID_COPYTOCLIPBOARD              40003

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40004
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
